// Test setup file - runs before tests
process.env.NODE_ENV = 'test';